In this directory you can find all the patch used for V9_2_0 building :

CGAL		4.0			: cgal_cmake352.patch
FREEIMAGE	3.1.6			: 
GL2PS		1.4.0-20170729		: gl2ps.patch
OCC		7.2.0p3			: OCCT-7.2.0.patch
OMNIORBPY	4.2.2			: omniORBpy-4.2.1-2-python3.patch
OPENTURNS_WRAPY	0.7			: otwrapy_0.7_py3.patch
PARAVIEW	v5.6.0			: ParaView-5.4.0-463c0633-vtkXOpenGLRenderWindow.cxx.patch, patch_pv_b5c4c893_py_catalyst.patch
PILLOW		3.4.2			: pillow-py3.patch 
SCOTCH		6.0.4			: scotch604_Make.inc.patch
SPHINX		1.2.3			: sphinx176_w_intl_napoleon.patch
