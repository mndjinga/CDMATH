Linked into target 'medcoupling' library. 
