#ifndef _GLVISVECIMPL_H
#define _GLVISVECIMPL_H

#include <petscviewer.h>
#include <petscvec.h>

PETSC_EXTERN PetscErrorCode VecView_GLVis(Vec,PetscViewer);

#endif
